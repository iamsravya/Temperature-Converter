window.addEventListener("DOMContentLoaded", domLoaded);
function domLoaded() {
  const convertButtonEl = document.getElementById("convertButton");
  const cInput = document.getElementById("cInput");
  const fInput = document.getElementById("fInput");
  const weatherImage = document.getElementById("weatherImage");
  weatherImage.style.display = "none";

  convertButtonEl.addEventListener("click", function () {
    let cValue = parseFloat(cInput.value);
    let fValue = parseFloat(fInput.value);

    if (Number.isNaN(cValue) && fInput.value == "") {
      errorMessage.innerHTML = cInput.value + " is not a number";
      return false; // stop click funtion here
    } else if (Number.isNaN(fValue) && cInput.value == "") {
      errorMessage.innerHTML = fInput.value + " is not a number";
      return false; // stop click funtion here
    }

    if (Number.isNaN(cValue) == false) {
      fValue = convertCtoF(cValue);
      fInput.value = fValue;
    } else if (Number.isNaN(fValue) == false) {
      cValue = convertFtoC(fValue);
      cInput.value = cValue;
    }

    if (fValue < 32) {
      weatherImage.src = "cold.png";
    } else if (fValue <= 50) {
      weatherImage.src = "cool.png";
    } else {
      weatherImage.src = "warm.png";
    }

    errorMessage.innerHTML = "";
    weatherImage.style.display = "block";
  });

  cInput.addEventListener("input", function () {
    if (fInput.value != "") {
      fInput.value = "";
    }
    weatherImage.style.display = "none";
  });

  fInput.addEventListener("input", function () {
    if (cInput.value != "") {
      cInput.value = "";
    }
    weatherImage.style.display = "none";
  });
}

function convertCtoF(degreesCelsius) {
    return degreesCelsius * (9 / 5) + 32;
  }
  
function convertFtoC(degreesFahrenheit) {
    return ((degreesFahrenheit - 32) * 5) / 9;
  }

